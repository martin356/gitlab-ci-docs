## Overview

The purpose of the packege is to generate simple documentation of gitlab-ci.